%% description
% This script runs a simulation with the segway in the simulator
% framework, using RTD to plan online.
%
% Author: Shreyas Kousik
% Created: 13 Mar 2020
% Updated: 27 Mar 2020
%
%% user parameters
% planner
buffer = 0.1 ; % m; b
buffer_t = 0.1; % m; bt
t_plan = 0.5 ; % if t_plan = t_move, then real time planning is enforced
t_move = 0.5 ;
FRS_degree = 12 ;
plot_FRS_flag = true ;
plot_HLP_flag = true ;
plot_waypoints_flag = true ;


% agent
% sensor_radius = 4;  
stopping_time = 1; % t_braking
max_speed = 1.5; % agent max speed ; vmax
obstacle_max_speed = 1; %%%%%%%world%%%%%% obstacle max speed ; vobs,max 
vrel = max_speed + obstacle_max_speed ; % vrel
sensor_radius = (t_plan+stopping_time)*vrel;

% world
obstacle_size_bounds = [0.3, 0.3] ; % side length [min, max]
N_obstacles = 6 ;
bounds = [-10,10,-5,5] ;
goal_radius = 0.5 ;
t_disc = (2*buffer_t)/vrel; %s
t_f = t_plan+stopping_time;

% simulation
verbose_level = 10 ;
max_sim_time = 3000 ;
max_sim_iterations = 1000 ;

% plotting
plot_while_simulating_flag = true ;
animate_after_simulating_flag = false ;

%% automated from here

A = segway_agent('sensor_radius',sensor_radius,...
    'max_speed',max_speed) ;

P = segway_RTD_planner('verbose',verbose_level,...
    'buffer',buffer,'buffer_t',buffer_t,...
    't_plan',t_plan,'t_move',t_move,...
    'FRS_degree',FRS_degree,...
    'plot_FRS_flag',plot_FRS_flag,...
    'plot_HLP_flag',plot_HLP_flag,...
    'plot_waypoints_flag',plot_waypoints_flag);

W = static_box_world('bounds',bounds,'N_obstacles',N_obstacles,'buffer',A.footprint+buffer,...
    'verbose',verbose_level,'goal_radius',goal_radius,...
    'obstacle_size_bounds',obstacle_size_bounds,...
    't_disc',t_disc,'t_f',t_f,...
    'vrel',vrel);

S = simulator(A,W,P,'allow_replan_errors',true,'verbose',verbose_level,...
    'max_sim_time',max_sim_time,...
    'max_sim_iterations',max_sim_iterations,...
    'plot_while_running',plot_while_simulating_flag);

%% run simulation
S.run() ;

%% animate simulation
if animate_after_simulating_flag
    S.animate()
end
clear
