# Experiment 2

This experiment compares RTD, RRT, and NMPC for the Segway and Rover on 1000 random worlds. In this experiment, we enforce a real-time limit on planning, and a limited sensor horizon (based on the LIDAR sensors on the actual robots).