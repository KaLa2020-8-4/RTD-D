# Experiment 3

In this experiment, we show that RTD can still plan safely when subject to a real-time planning limit and minimal sensor horizon. We do not test RRT or NMPC in this experiment.